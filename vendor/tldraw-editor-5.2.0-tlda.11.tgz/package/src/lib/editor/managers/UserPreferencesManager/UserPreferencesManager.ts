import { atom, computed } from '@tldraw/state'
import { createUserId, TLUserId } from '@tldraw/tlschema'
import { TLCurrentUser } from '../../../config/createTLCurrentUser'
import { TLUserPreferences, defaultUserPreferences } from '../../../config/TLUserPreferences'
import { getGlobalWindow } from '../../../utils/dom'

/** @public */
export class UserPreferencesManager {
	systemColorScheme = atom<'dark' | 'light'>('systemColorScheme', 'light')
	disposables = new Set<() => void>()
	dispose() {
		this.disposables.forEach((d) => d())
	}
	constructor(
		private readonly user: TLCurrentUser,
		private readonly colorScheme: 'light' | 'dark' | 'system'
	) {
		if (typeof window === 'undefined' || !getGlobalWindow().matchMedia) return

		const darkModeMediaQuery = getGlobalWindow().matchMedia('(prefers-color-scheme: dark)')
		if (darkModeMediaQuery?.matches) {
			this.systemColorScheme.set('dark')
		}
		const handleChange = (e: MediaQueryListEvent) => {
			if (e.matches) {
				this.systemColorScheme.set('dark')
			} else {
				this.systemColorScheme.set('light')
			}
		}
		darkModeMediaQuery?.addEventListener('change', handleChange)
		this.disposables.add(() => darkModeMediaQuery?.removeEventListener('change', handleChange))
	}

	updateUserPreferences(userPreferences: Partial<TLUserPreferences>) {
		this.user.setUserPreferences({
			...this.user.userPreferences.get(),
			...userPreferences,
		})
	}
	@computed getUserPreferences() {
		return {
			id: this.getExternalId(),
			name: this.getName(),
			locale: this.getLocale(),
			color: this.getColor(),
			animationSpeed: this.getAnimationSpeed(),
			areKeyboardShortcutsEnabled: this.getAreKeyboardShortcutsEnabled(),
			isSnapMode: this.getIsSnapMode(),
			colorScheme: this.user.userPreferences.get().colorScheme,
			isDarkMode: this.getIsDarkMode(),
			isWrapMode: this.getIsWrapMode(),
			isDynamicResizeMode: this.getIsDynamicResizeMode(),
			enhancedA11yMode: this.getEnhancedA11yMode(),
			inputMode: this.getInputMode(),
			isZoomDirectionInverted: this.getIsZoomDirectionInverted(),
		}
	}

	@computed getIsDarkMode() {
		const userColorScheme = this.user.userPreferences.get().colorScheme
		const scheme = userColorScheme ?? this.colorScheme
		switch (scheme) {
			case 'dark':
				return true
			case 'light':
				return false
			case 'system':
				return this.systemColorScheme.get() === 'dark'
			default:
				return false
		}
	}

	/**
	 * The speed at which the user can scroll by dragging toward the edge of the screen.
	 */
	@computed getEdgeScrollSpeed() {
		return this.user.userPreferences.get().edgeScrollSpeed ?? defaultUserPreferences.edgeScrollSpeed
	}

	@computed getAnimationSpeed() {
		return this.user.userPreferences.get().animationSpeed ?? defaultUserPreferences.animationSpeed
	}

	@computed getAreKeyboardShortcutsEnabled() {
		return (
			this.user.userPreferences.get().areKeyboardShortcutsEnabled ??
			defaultUserPreferences.areKeyboardShortcutsEnabled
		)
	}

	/**
	 * The current user's raw, app-provided id — the value set in the user's
	 * {@link @tldraw/editor#TLUserPreferences}. Use this when you need the id your application
	 * assigned to the user. To compare against or look up store records, use
	 * {@link UserPreferencesManager.getRecordId} instead.
	 */
	@computed getExternalId(): string {
		return this.user.userPreferences.get().id
	}

	/**
	 * @deprecated Use {@link UserPreferencesManager.getExternalId} for the raw app-provided id, or
	 * {@link UserPreferencesManager.getRecordId} for the prefixed `TLUserId` record id.
	 */
	@computed getId() {
		return this.getExternalId()
	}

	/**
	 * The current user's id as a tldraw {@link @tldraw/tlschema#TLUserId} record id (prefixed
	 * with `user:`). Use this when comparing against or looking up store records, such as a
	 * presence record's `userId` or `followingUserId`. For the raw, app-provided id, use
	 * {@link UserPreferencesManager.getExternalId}.
	 */
	@computed getRecordId(): TLUserId {
		return createUserId(this.getExternalId())
	}

	@computed getName() {
		return this.user.userPreferences.get().name?.trim() ?? defaultUserPreferences.name
	}

	@computed getLocale() {
		return this.user.userPreferences.get().locale ?? defaultUserPreferences.locale
	}

	@computed getColor() {
		return this.user.userPreferences.get().color ?? defaultUserPreferences.color
	}

	@computed getIsSnapMode() {
		return this.user.userPreferences.get().isSnapMode ?? defaultUserPreferences.isSnapMode
	}

	@computed getIsWrapMode() {
		return this.user.userPreferences.get().isWrapMode ?? defaultUserPreferences.isWrapMode
	}

	@computed getIsDynamicResizeMode() {
		return (
			this.user.userPreferences.get().isDynamicSizeMode ?? defaultUserPreferences.isDynamicSizeMode
		)
	}

	@computed getIsPasteAtCursorMode() {
		return (
			this.user.userPreferences.get().isPasteAtCursorMode ??
			defaultUserPreferences.isPasteAtCursorMode
		)
	}

	@computed getEnhancedA11yMode() {
		return (
			this.user.userPreferences.get().enhancedA11yMode ?? defaultUserPreferences.enhancedA11yMode
		)
	}

	@computed getInputMode() {
		return this.user.userPreferences.get().inputMode ?? defaultUserPreferences.inputMode
	}

	@computed getIsZoomDirectionInverted() {
		return (
			this.user.userPreferences.get().isZoomDirectionInverted ??
			defaultUserPreferences.isZoomDirectionInverted
		)
	}
}
