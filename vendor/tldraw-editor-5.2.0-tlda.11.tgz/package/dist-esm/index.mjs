import { registerTldrawLibraryVersion } from "@tldraw/utils";
export * from "@tldraw/state";
export * from "@tldraw/state-react";
export * from "@tldraw/store";
export * from "@tldraw/tlschema";
export * from "@tldraw/utils";
export * from "@tldraw/validate";
import { DefaultBackground } from "./lib/components/default-components/DefaultBackground.mjs";
import {
  DefaultCanvas
} from "./lib/components/default-components/DefaultCanvas.mjs";
import {
  DefaultErrorFallback
} from "./lib/components/default-components/DefaultErrorFallback.mjs";
import { DefaultGrid } from "./lib/components/default-components/DefaultGrid.mjs";
import {
  DefaultShapeWrapper
} from "./lib/components/default-components/DefaultShapeWrapper.mjs";
import { DefaultSpinner } from "./lib/components/default-components/DefaultSpinner.mjs";
import { DefaultSvgDefs } from "./lib/components/default-components/DefaultSvgDefs.mjs";
import {
  ErrorBoundary,
  OptionalErrorBoundary
} from "./lib/components/ErrorBoundary.mjs";
import { HTMLContainer } from "./lib/components/HTMLContainer.mjs";
import { MenuClickCapture } from "./lib/components/MenuClickCapture.mjs";
import { SVGContainer } from "./lib/components/SVGContainer.mjs";
import { TldrawViewport } from "./lib/components/TldrawViewport.mjs";
import {
  createTLCurrentUser,
  useTldrawCurrentUser
} from "./lib/config/createTLCurrentUser.mjs";
import {
  createTLSchemaFromUtils,
  createTLStore,
  defaultUserStore,
  inlineBase64AssetStore
} from "./lib/config/createTLStore.mjs";
import { coreShapes } from "./lib/config/defaultShapes.mjs";
import {
  getSnapshot,
  loadSnapshot
} from "./lib/config/TLEditorSnapshot.mjs";
import {
  createSessionStateSnapshotSignal,
  extractSessionStateFromLegacySnapshot,
  loadSessionStateSnapshotIntoStore,
  TAB_ID
} from "./lib/config/TLSessionStateSnapshot.mjs";
import {
  defaultUserPreferences,
  getFreshUserPreferences,
  getUserPreferences,
  setUserPreferences,
  USER_COLORS,
  userTypeValidator
} from "./lib/config/TLUserPreferences.mjs";
import { DEFAULT_ANIMATION_OPTIONS, DEFAULT_CAMERA_OPTIONS, SIDES } from "./lib/constants.mjs";
import { AssetUtil } from "./lib/editor/assets/AssetUtil.mjs";
import {
  BindingUtil
} from "./lib/editor/bindings/BindingUtil.mjs";
import {
  Editor
} from "./lib/editor/Editor.mjs";
import {
  DEFAULT_VIEWPORT_ID,
  getViewportPageBounds
} from "./lib/editor/viewports/TLViewport.mjs";
import { ClickManager } from "./lib/editor/managers/ClickManager/ClickManager.mjs";
import { EdgeScrollManager } from "./lib/editor/managers/EdgeScrollManager/EdgeScrollManager.mjs";
import { FontManager } from "./lib/editor/managers/FontManager/FontManager.mjs";
import { HistoryManager } from "./lib/editor/managers/HistoryManager/HistoryManager.mjs";
import { InputsManager } from "./lib/editor/managers/InputsManager/InputsManager.mjs";
import {
  ScribbleManager
} from "./lib/editor/managers/ScribbleManager/ScribbleManager.mjs";
import {
  BoundsSnaps
} from "./lib/editor/managers/SnapManager/BoundsSnaps.mjs";
import { HandleSnaps } from "./lib/editor/managers/SnapManager/HandleSnaps.mjs";
import {
  SnapManager
} from "./lib/editor/managers/SnapManager/SnapManager.mjs";
import { SpatialIndexManager } from "./lib/editor/managers/SpatialIndexManager/SpatialIndexManager.mjs";
import {
  TextManager,
  resolveLineHeightPx
} from "./lib/editor/managers/TextManager/TextManager.mjs";
import { DEFAULT_THEME } from "./lib/editor/managers/ThemeManager/defaultThemes.mjs";
import { ThemeManager, resolveThemes } from "./lib/editor/managers/ThemeManager/ThemeManager.mjs";
import { TickManager } from "./lib/editor/managers/TickManager/TickManager.mjs";
import { CollaboratorsManager } from "./lib/editor/managers/CollaboratorsManager/CollaboratorsManager.mjs";
import { PerformanceApiAdapter } from "./lib/editor/managers/PerformanceManager/PerformanceApiAdapter.mjs";
import { PerformanceManager } from "./lib/editor/managers/PerformanceManager/PerformanceManager.mjs";
import { UserPreferencesManager } from "./lib/editor/managers/UserPreferencesManager/UserPreferencesManager.mjs";
import { BaseBoxShapeUtil } from "./lib/editor/shapes/BaseBoxShapeUtil.mjs";
import { BaseFrameLikeShapeUtil } from "./lib/editor/shapes/BaseFrameLikeShapeUtil.mjs";
import { GroupShapeUtil } from "./lib/editor/shapes/group/GroupShapeUtil.mjs";
import {
  ShapeUtil
} from "./lib/editor/shapes/ShapeUtil.mjs";
import {
  getOverlayDisplayValues
} from "./lib/editor/overlays/getOverlayDisplayValues.mjs";
import { OverlayManager } from "./lib/editor/overlays/OverlayManager.mjs";
import {
  OverlayUtil
} from "./lib/editor/overlays/OverlayUtil.mjs";
import { strokeShapeIndicators } from "./lib/editor/overlays/strokeShapeIndicators.mjs";
import {
  getPerfectDashProps
} from "./lib/editor/shapes/shared/getPerfectDashProps.mjs";
import { resizeBox } from "./lib/editor/shapes/shared/resizeBox.mjs";
import { resizeScaled } from "./lib/editor/shapes/shared/resizeScaled.mjs";
import { BaseBoxShapeTool } from "./lib/editor/tools/BaseBoxShapeTool/BaseBoxShapeTool.mjs";
import { maybeSnapToGrid } from "./lib/editor/tools/BaseBoxShapeTool/children/Pointing.mjs";
import { cancelShapeCreationOnLongPress } from "./lib/editor/tools/cancelShapeCreationOnLongPress.mjs";
import { StateNode } from "./lib/editor/tools/StateNode.mjs";
import {
  EVENT_NAME_MAP
} from "./lib/editor/types/event-types.mjs";
import {
  useDelaySvgExport,
  useSvgExportContext
} from "./lib/editor/types/SvgExportContext.mjs";
import { getOwnerDocument, getOwnerWindow } from "./lib/exports/domUtils.mjs";
import { getSvgAsImage } from "./lib/exports/getSvgAsImage.mjs";
import { tlenv, tlenvReactive } from "./lib/globals/environment.mjs";
import { tlmenus } from "./lib/globals/menus.mjs";
import { tltime } from "./lib/globals/time.mjs";
import {
  ContainerProvider,
  useContainer,
  useContainerIfExists
} from "./lib/hooks/useContainer.mjs";
import { useColorMode } from "./lib/hooks/useColorMode.mjs";
import { getCursor } from "./lib/hooks/useCursor.mjs";
import {
  DEFAULT_GESTURE_TUNING,
  GestureInterpreter
} from "./lib/hooks/gesture/GestureInterpreter.mjs";
import {
  EditorContext,
  EditorProvider,
  useEditor,
  useMaybeEditor
} from "./lib/hooks/useEditor.mjs";
import { useEditorComponents } from "./lib/hooks/useEditorComponents.mjs";
import { useEvent, useReactiveEvent } from "./lib/hooks/useEvent.mjs";
import { useGlobalMenuIsOpen } from "./lib/hooks/useGlobalMenuIsOpen.mjs";
import { useShallowArrayIdentity, useShallowObjectIdentity } from "./lib/hooks/useIdentity.mjs";
import { useIsCropping } from "./lib/hooks/useIsCropping.mjs";
import { useIsEditing } from "./lib/hooks/useIsEditing.mjs";
import { useLocalStore } from "./lib/hooks/useLocalStore.mjs";
import { usePassThroughMouseOverEvents } from "./lib/hooks/usePassThroughMouseOverEvents.mjs";
import { usePassThroughWheelEvents } from "./lib/hooks/usePassThroughWheelEvents.mjs";
import { usePeerIds } from "./lib/hooks/usePeerIds.mjs";
import { usePresence } from "./lib/hooks/usePresence.mjs";
import { useRefState } from "./lib/hooks/useRefState.mjs";
import {
  sanitizeId,
  suffixSafeId,
  useSharedSafeId,
  useUniqueSafeId
} from "./lib/hooks/useSafeId.mjs";
import { useTLSchemaFromUtils, useTLStore } from "./lib/hooks/useTLStore.mjs";
import { useViewportHeight } from "./lib/hooks/useViewportHeight.mjs";
import {
  LicenseManager
} from "./lib/license/LicenseManager.mjs";
import { LICENSE_TIMEOUT } from "./lib/license/LicenseProvider.mjs";
import {
  defaultTldrawOptions
} from "./lib/options.mjs";
import {
  Box,
  ROTATE_CORNER_TO_SELECTION_CORNER,
  rotateSelectionHandle
} from "./lib/primitives/Box.mjs";
import { EASINGS } from "./lib/primitives/easings.mjs";
import { Arc2d } from "./lib/primitives/geometry/Arc2d.mjs";
import { Circle2d } from "./lib/primitives/geometry/Circle2d.mjs";
import { CubicBezier2d } from "./lib/primitives/geometry/CubicBezier2d.mjs";
import { CubicSpline2d } from "./lib/primitives/geometry/CubicSpline2d.mjs";
import { Edge2d } from "./lib/primitives/geometry/Edge2d.mjs";
import { Ellipse2d } from "./lib/primitives/geometry/Ellipse2d.mjs";
import { getVerticesCountForArcLength } from "./lib/primitives/geometry/geometry-constants.mjs";
import {
  Geometry2d,
  Geometry2dFilters,
  TransformedGeometry2d
} from "./lib/primitives/geometry/Geometry2d.mjs";
import { Group2d } from "./lib/primitives/geometry/Group2d.mjs";
import { Point2d } from "./lib/primitives/geometry/Point2d.mjs";
import { Polygon2d } from "./lib/primitives/geometry/Polygon2d.mjs";
import { Polyline2d } from "./lib/primitives/geometry/Polyline2d.mjs";
import { Rectangle2d } from "./lib/primitives/geometry/Rectangle2d.mjs";
import { Stadium2d } from "./lib/primitives/geometry/Stadium2d.mjs";
import {
  intersectCircleCircle,
  intersectCirclePolygon,
  intersectCirclePolyline,
  intersectLineSegmentCircle,
  intersectLineSegmentLineSegment,
  intersectLineSegmentPolygon,
  intersectLineSegmentPolyline,
  intersectPolygonBounds,
  intersectPolygonPolygon,
  linesIntersect,
  polygonIntersectsPolyline,
  polygonsIntersect
} from "./lib/primitives/intersect.mjs";
import { Mat } from "./lib/primitives/Mat.mjs";
import {
  angleDistance,
  approximately,
  areAnglesCompatible,
  average,
  canonicalizeRotation,
  centerOfCircleFromThreePoints,
  clamp,
  clampRadians,
  clockwiseAngleDist,
  counterClockwiseAngleDist,
  degreesToRadians,
  getArcMeasure,
  getPointInArcT,
  getPointOnCircle,
  getPointsOnArc,
  getPolygonVertices,
  HALF_PI,
  isSafeFloat,
  perimeterOfEllipse,
  PI,
  PI2,
  pointInPolygon,
  precise,
  radiansToDegrees,
  rangeIntersection,
  shortAngleDist,
  SIN,
  snapAngle,
  toDomPrecision,
  toFixed,
  toPrecision
} from "./lib/primitives/utils.mjs";
import { Vec } from "./lib/primitives/Vec.mjs";
import {
  ErrorScreen,
  LoadingScreen,
  TldrawEditor,
  useOnMount
} from "./lib/TldrawEditor.mjs";
import { dataUrlToFile, getDefaultCdnBaseUrl } from "./lib/utils/assets.mjs";
import { clampToBrowserMaxCanvasSize } from "./lib/utils/browserCanvasMaxSize.mjs";
import {
  createDebugValue,
  debugFlags,
  featureFlags
} from "./lib/utils/debug-flags.mjs";
import {
  createDeepLinkString,
  parseDeepLinkString
} from "./lib/utils/deepLinks.mjs";
import {
  activeElementShouldCaptureKeys,
  elementShouldCaptureKeys,
  getGlobalDocument,
  getGlobalWindow,
  loopToHtmlElement,
  moveElementInto,
  preventDefault,
  releasePointerCapture,
  setPointerCapture,
  stopEventPropagation
} from "./lib/utils/dom.mjs";
import { EditorAtom } from "./lib/utils/EditorAtom.mjs";
import { getIncrementedName } from "./lib/utils/getIncrementedName.mjs";
import { getPointerInfo } from "./lib/utils/getPointerInfo.mjs";
import { getSvgPathFromPoints } from "./lib/utils/getSvgPathFromPoints.mjs";
import { isAccelKey } from "./lib/utils/keyboard.mjs";
import { normalizeWheel } from "./lib/utils/normalizeWheel.mjs";
import { getDroppedShapesToNewParents, kickoutOccludedShapes } from "./lib/utils/reparenting.mjs";
import {
  getFontsFromRichText
} from "./lib/utils/richText.mjs";
import {
  applyRotationToSnapshotShapes,
  getRotationSnapshot
} from "./lib/utils/rotation.mjs";
import {
  hardResetEditor,
  openWindow,
  refreshPage,
  runtime,
  setRuntimeOverrides
} from "./lib/utils/runtime.mjs";
import {
  ReadonlySharedStyleMap,
  SharedStyleMap
} from "./lib/utils/SharedStylesMap.mjs";
import { hardReset } from "./lib/utils/sync/hardReset.mjs";
import { LocalIndexedDb, Table } from "./lib/utils/sync/LocalIndexedDb.mjs";
import { uniq } from "./lib/utils/uniq.mjs";
registerTldrawLibraryVersion(
  "@tldraw/editor",
  "5.2.0",
  "esm"
);
import { getColorValue } from "./lib/editor/managers/ThemeManager/defaultThemes.mjs";
export {
  Arc2d,
  AssetUtil,
  BaseBoxShapeTool,
  BaseBoxShapeUtil,
  BaseFrameLikeShapeUtil,
  BindingUtil,
  BoundsSnaps,
  Box,
  Circle2d,
  ClickManager,
  CollaboratorsManager,
  ContainerProvider,
  CubicBezier2d,
  CubicSpline2d,
  DEFAULT_ANIMATION_OPTIONS,
  DEFAULT_CAMERA_OPTIONS,
  DEFAULT_GESTURE_TUNING,
  DEFAULT_THEME,
  DEFAULT_VIEWPORT_ID,
  DefaultBackground,
  DefaultCanvas,
  DefaultErrorFallback,
  DefaultGrid,
  DefaultShapeWrapper,
  DefaultSpinner,
  DefaultSvgDefs,
  EASINGS,
  EVENT_NAME_MAP,
  Edge2d,
  EdgeScrollManager,
  Editor,
  EditorAtom,
  EditorContext,
  EditorProvider,
  Ellipse2d,
  ErrorBoundary,
  ErrorScreen,
  FontManager,
  Geometry2d,
  Geometry2dFilters,
  GestureInterpreter,
  Group2d,
  GroupShapeUtil,
  HALF_PI,
  HTMLContainer,
  HandleSnaps,
  HistoryManager,
  InputsManager,
  LICENSE_TIMEOUT,
  LicenseManager,
  LoadingScreen,
  LocalIndexedDb,
  Mat,
  MenuClickCapture,
  OptionalErrorBoundary,
  OverlayManager,
  OverlayUtil,
  PI,
  PI2,
  PerformanceApiAdapter,
  PerformanceManager,
  Point2d,
  Polygon2d,
  Polyline2d,
  ROTATE_CORNER_TO_SELECTION_CORNER,
  ReadonlySharedStyleMap,
  Rectangle2d,
  SIDES,
  SIN,
  SVGContainer,
  ScribbleManager,
  ShapeUtil,
  SharedStyleMap,
  SnapManager,
  SpatialIndexManager,
  Stadium2d,
  StateNode,
  TAB_ID,
  Table,
  TextManager,
  ThemeManager,
  TickManager,
  TldrawEditor,
  TldrawViewport,
  TransformedGeometry2d,
  USER_COLORS,
  UserPreferencesManager,
  Vec,
  activeElementShouldCaptureKeys,
  angleDistance,
  applyRotationToSnapshotShapes,
  approximately,
  areAnglesCompatible,
  average,
  cancelShapeCreationOnLongPress,
  canonicalizeRotation,
  centerOfCircleFromThreePoints,
  clamp,
  clampRadians,
  clampToBrowserMaxCanvasSize,
  clockwiseAngleDist,
  coreShapes,
  counterClockwiseAngleDist,
  createDebugValue,
  createDeepLinkString,
  createSessionStateSnapshotSignal,
  createTLCurrentUser,
  createTLSchemaFromUtils,
  createTLStore,
  dataUrlToFile,
  debugFlags,
  defaultTldrawOptions,
  defaultUserPreferences,
  defaultUserStore,
  degreesToRadians,
  elementShouldCaptureKeys,
  extractSessionStateFromLegacySnapshot,
  featureFlags,
  getArcMeasure,
  getColorValue,
  getCursor,
  getDefaultCdnBaseUrl,
  getDroppedShapesToNewParents,
  getFontsFromRichText,
  getFreshUserPreferences,
  getGlobalDocument,
  getGlobalWindow,
  getIncrementedName,
  getOverlayDisplayValues,
  getOwnerDocument,
  getOwnerWindow,
  getPerfectDashProps,
  getPointInArcT,
  getPointOnCircle,
  getPointerInfo,
  getPointsOnArc,
  getPolygonVertices,
  getRotationSnapshot,
  getSnapshot,
  getSvgAsImage,
  getSvgPathFromPoints,
  getUserPreferences,
  getVerticesCountForArcLength,
  getViewportPageBounds,
  hardReset,
  hardResetEditor,
  inlineBase64AssetStore,
  intersectCircleCircle,
  intersectCirclePolygon,
  intersectCirclePolyline,
  intersectLineSegmentCircle,
  intersectLineSegmentLineSegment,
  intersectLineSegmentPolygon,
  intersectLineSegmentPolyline,
  intersectPolygonBounds,
  intersectPolygonPolygon,
  isAccelKey,
  isSafeFloat,
  kickoutOccludedShapes,
  linesIntersect,
  loadSessionStateSnapshotIntoStore,
  loadSnapshot,
  loopToHtmlElement,
  maybeSnapToGrid,
  moveElementInto,
  normalizeWheel,
  openWindow,
  parseDeepLinkString,
  perimeterOfEllipse,
  pointInPolygon,
  polygonIntersectsPolyline,
  polygonsIntersect,
  precise,
  preventDefault,
  radiansToDegrees,
  rangeIntersection,
  refreshPage,
  releasePointerCapture,
  resizeBox,
  resizeScaled,
  resolveLineHeightPx,
  resolveThemes,
  rotateSelectionHandle,
  runtime,
  sanitizeId,
  setPointerCapture,
  setRuntimeOverrides,
  setUserPreferences,
  shortAngleDist,
  snapAngle,
  stopEventPropagation,
  strokeShapeIndicators,
  suffixSafeId,
  tlenv,
  tlenvReactive,
  tlmenus,
  tltime,
  toDomPrecision,
  toFixed,
  toPrecision,
  uniq,
  useColorMode,
  useContainer,
  useContainerIfExists,
  useDelaySvgExport,
  useEditor,
  useEditorComponents,
  useEvent,
  useGlobalMenuIsOpen,
  useIsCropping,
  useIsEditing,
  useLocalStore,
  useMaybeEditor,
  useOnMount,
  usePassThroughMouseOverEvents,
  usePassThroughWheelEvents,
  usePeerIds,
  usePresence,
  useReactiveEvent,
  useRefState,
  useShallowArrayIdentity,
  useShallowObjectIdentity,
  useSharedSafeId,
  useSvgExportContext,
  useTLSchemaFromUtils,
  useTLStore,
  useTldrawCurrentUser,
  useUniqueSafeId,
  useViewportHeight,
  userTypeValidator
};
//# sourceMappingURL=index.mjs.map
