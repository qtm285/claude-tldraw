const version = "5.2.0";
const publishDates = {
  major: "2026-05-06T16:28:18.473Z",
  minor: "2026-07-01T09:20:01.735Z",
  patch: "2026-07-01T09:20:01.735Z"
};
export {
  publishDates,
  version
};
//# sourceMappingURL=version.mjs.map
